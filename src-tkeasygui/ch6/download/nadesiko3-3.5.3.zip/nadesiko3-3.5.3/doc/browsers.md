# なでしこ3 対応ブラウザ一覧

日本語プログラミング言語「なでしこ3」は以下のブラウザに対応しています。

## デスクトップ

- Edge (120/119/118以上)
- Firefox (121/120/119/115以上)
- Chrome (120/119/118/117/116/109以上)
- Safari (17.2/17.1/16.6/15.6以上)
- Opera (104/103/102以上)
- Node.js (21.3.0/20.10.0/18.19.0以上)

## モバイル

- Safari on iOS (17.1/17.0/16.6-16.7/16.5/16.3/16.2/16.1/16.0/15.6-15.7以上)
- Opera Mini (all以上)
- Android Browser (120以上)
- Opera Mobile (73以上)
- Chrome for Android (120以上)
- Firefox for Android (119以上)
- UC Browser for Android (15.5以上)
- Samsung Internet (23/22以上)
- QQ Browser (13.1以上)
- KaiOS Browser (3.0-3.1/2.5以上)
