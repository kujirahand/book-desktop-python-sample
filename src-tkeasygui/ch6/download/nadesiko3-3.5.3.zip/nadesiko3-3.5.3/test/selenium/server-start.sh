#!/bin/sh
php -S localhost:8887

